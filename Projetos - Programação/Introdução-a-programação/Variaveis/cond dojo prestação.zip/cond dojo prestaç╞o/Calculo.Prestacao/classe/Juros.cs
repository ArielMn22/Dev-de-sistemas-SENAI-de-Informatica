namespace Calculo.Prestacao.classe
{
    public class Juros
    {
        public string nome;

        public float vReal;

        public int qPrestacao;

        public float vPrestacao;

        public float vAcrescimo;

        public float vMensal;

        public float vTotal;
    }
}